#pragma once

#include <cstdint>
#include <string>

std::string get_keycode_identifier_or_default(uint16_t keycode);
