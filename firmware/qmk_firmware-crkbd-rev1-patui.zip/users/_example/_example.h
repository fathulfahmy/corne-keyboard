#ifndef USERSPACE
#define USERSPACE

#include "quantum.h"

void my_custom_function(void);

#endif